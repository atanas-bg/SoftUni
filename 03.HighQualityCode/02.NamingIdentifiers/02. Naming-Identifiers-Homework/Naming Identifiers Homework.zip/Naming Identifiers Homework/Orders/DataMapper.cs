﻿using System.Collections.Generic;
using System.Linq;
using o;
using System.IO;

namespace Orders
{
    public class dataMapper
    {
        private string categoriesFileName;
        private string productsFileName;
        private string ordersFileName;

        public dataMapper(string categoriesFileName, string productsFileName, string ordersFileName)
        {
            this.categoriesFileName = categoriesFileName;
            this.productsFileName = productsFileName;
            this.ordersFileName = ordersFileName;
        }

        public dataMapper()
            : this("../../Data/categories.txt", "../../Data/products.txt", "../../Data/orders.txt")
        {
        }

        public IEnumerable<category> getAllCategories()
        {
            var cat = ReadFileLines(this.categoriesFileName, true);
            return cat
                .Select(c => c.Split(','))
                .Select(c => new category
                {
                    id = int.Parse(c[0]),
                    name = c[1],
                    description = c[2]
                });
        }

        public IEnumerable<product> getAllProducts()
        {
            var product = ReadFileLines(this.productsFileName, true);
            return product
                .Select(p => p.Split(','))
                .Select(p => new product
                {
                    id = int.Parse(p[0]),
                    name = p[1],
                    catId = int.Parse(p[2]),
                    unitPrice = decimal.Parse(p[3]),
                    unitsInStock = int.Parse(p[4]),
                });
        }

        public IEnumerable<order> getAllOrders()
        {
            var order = ReadFileLines(this.ordersFileName, true);
            return order
                .Select(p => p.Split(','))
                .Select(p => new order
                {
                    ID = int.Parse(p[0]),
                    productId = int.Parse(p[1]),
                    quantity = int.Parse(p[2]),
                    Discount = decimal.Parse(p[3]),
                });
        }

        private List<string> ReadFileLines(string filename, bool hasHeader)
        {
            var allLines = new List<string>();
            using (var reader = new StreamReader(filename))
            {
                string currentLine;
                if (hasHeader)
                {
                    reader.ReadLine();
                }

                while ((currentLine = reader.ReadLine()) != null)
                {
                    allLines.Add(currentLine);
                }
            }

            return allLines;
        }
    }
}
