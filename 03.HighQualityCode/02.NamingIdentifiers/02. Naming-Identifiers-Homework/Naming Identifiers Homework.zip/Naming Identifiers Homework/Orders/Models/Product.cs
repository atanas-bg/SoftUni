﻿namespace o
{
    public class product
    {
        public int id { get; set; }

        public string name { get; set; }

        public int catId { get; set; }

        public decimal unitPrice { get; set; }

        public int unitsInStock { get; set; }
    }
}
