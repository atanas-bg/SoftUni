﻿namespace o
{
    public class order
    {
        public int ID { get; set; }

        public int productId { get; set; }

        public int quantity { get; set; }

        public decimal Discount { get; set; }
    }
}
