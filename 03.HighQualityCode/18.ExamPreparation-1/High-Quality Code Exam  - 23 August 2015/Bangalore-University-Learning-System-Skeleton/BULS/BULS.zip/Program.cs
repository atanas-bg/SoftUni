﻿namespace BangaloreUniversityLearningSystem
{
    using Core;
    using Models;
    public class Program
    {
        public static void Main()
        {
            var engine = new BangaloreUniversityEngine();
            engine.Run();
        }
    }
}