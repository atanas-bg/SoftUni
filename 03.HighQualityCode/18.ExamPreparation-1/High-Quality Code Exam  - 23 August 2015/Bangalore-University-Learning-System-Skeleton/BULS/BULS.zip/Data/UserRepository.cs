﻿namespace BangaloreUniversityLearningSystem.Data
{
    using System.Collections.Generic;
    using System.Linq;
    using Models;

    public class UsersRepository : Repository<User>
    {
        private Dictionary<string, User> usersByUsername;

        public User GetByUsername(string username)
        {

            //if (this.usersByUsername.ContainsKey(username))
            //{
            //    return this.usersByUsername[username];
            //}

            return this.items.FirstOrDefault(u => u.UserName == username);
        }
    }
}
