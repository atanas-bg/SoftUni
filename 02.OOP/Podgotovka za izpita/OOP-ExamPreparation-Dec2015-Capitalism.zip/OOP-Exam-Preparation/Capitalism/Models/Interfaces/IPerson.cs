﻿namespace Capitalism.Models.Interfaces
{
    public interface IPerson
    {
        string FirstName { get; }

        string LastName { get; }
    }
}