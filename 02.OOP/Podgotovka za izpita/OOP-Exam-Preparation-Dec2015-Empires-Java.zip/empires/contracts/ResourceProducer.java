package empires.contracts;

public interface ResourceProducer {

    public Resource produceResource();    
}