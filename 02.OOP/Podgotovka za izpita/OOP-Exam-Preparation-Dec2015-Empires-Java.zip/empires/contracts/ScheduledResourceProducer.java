package empires.contracts;

public interface ScheduledResourceProducer extends ResourceProducer {
    
    public boolean canProduceResource();
}
