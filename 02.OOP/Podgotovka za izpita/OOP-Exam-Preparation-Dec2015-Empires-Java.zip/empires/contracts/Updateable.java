package empires.contracts;

public interface Updateable {

    public void update();
}