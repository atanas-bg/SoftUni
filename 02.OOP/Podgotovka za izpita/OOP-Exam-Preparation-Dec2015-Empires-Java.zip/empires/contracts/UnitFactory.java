package empires.contracts;

public interface UnitFactory {

    public Unit createUnit(String unitType);
}