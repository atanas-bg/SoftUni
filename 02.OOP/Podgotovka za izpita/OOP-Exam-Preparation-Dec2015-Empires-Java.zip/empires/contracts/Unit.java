package empires.contracts;

public interface Unit extends Destroyable, Attacker {
}