package empires.contracts;

public interface InputReader {

    public String readLine();
}