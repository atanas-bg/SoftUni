package empires.contracts;

public interface ScheduledUnitProducer extends UnitProducer {
    
    public boolean canProduceUnit();
}
