package empires.contracts;

public interface UnitProducer {

    public Unit produceUnit();    
}