package empires.contracts;

public interface Attacker {
    
    public int getAttackDamage();
}