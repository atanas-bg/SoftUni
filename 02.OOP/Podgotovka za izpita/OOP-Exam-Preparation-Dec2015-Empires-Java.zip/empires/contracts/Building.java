package empires.contracts;

public interface Building extends ScheduledResourceProducer, ScheduledUnitProducer, Updateable {
}