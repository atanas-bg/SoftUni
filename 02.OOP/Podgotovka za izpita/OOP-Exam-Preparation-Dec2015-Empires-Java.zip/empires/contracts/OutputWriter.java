package empires.contracts;

public interface OutputWriter {

    public void writeLine(String output);
}