package empires.contracts;

public interface Destroyable {
    
    public int getHealth();
    
    public void setHealth(int health);
}